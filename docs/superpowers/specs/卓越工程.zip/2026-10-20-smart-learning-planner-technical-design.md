# 智能学习规划助手技术设计说明书

> 文档状态：技术基线
>
> 文档版本：v1.0
>
> 日期：2026-10-20
>
> 项目周期：约 10 周
>
> 团队规模：2 人
>
> 需求基线：`docs/superpowers/specs/2026-09-30-smart-learning-planner-requirements-spec.md` v1.1
>
> 设计方案：`docs/superpowers/specs/2026-09-30-smart-learning-planner-design.md` v1.3
>
> 核心验收：单次现场连续完成目标、诊断、规划、打卡、验收和重规划

## 1. 文档目的

本文档将产品设计方案和需求规格转换为可开发、可测试、可部署的技术设计。它重点回答：

- 系统由哪些模块组成，各模块负责什么。
- 模块之间通过什么数据结构、接口和事务边界协作。
- 首次学习计划与学习后重规划如何落到同一套 Agent 和数据模型。
- RAG、知识图谱、路径规划、规则校验和 BKT 如何共同保证结果可信。
- 两名开发者如何在不频繁冲突的前提下并行实现并完成现场闭环。

本文档不替代 SRS。用户可见行为以 SRS 为准，代码实现以本文档的模块边界和接口契约为准。

## 2. 技术目标与约束

### 2.1 技术目标

- 在 Windows 11 单机环境中运行前端、FastAPI、SQLite、Chroma 和 Ollama。
- 现场由真实请求触发六阶段闭环，不依赖固定响应或人工改库。
- LLM 只负责理解、生成候选和解释，路径可行性由确定性算法判断。
- 所有引用可回溯到真实文档片段，所有掌握度变化可回溯到证据和参数版本。
- 核心链路可恢复、可重试、可观察，并支持三次连续演示。
- 训练流水线与在线 API 解耦，训练中断不阻塞在线演示数据。

### 2.2 关键约束

| 约束 | 技术决策 |
| --- | --- |
| 10 周、2 人 | 采用模块化单体，不引入微服务、消息队列和独立认证服务 |
| 本地单用户 | 默认用户固定为本机学生账户，不实现登录和权限系统 |
| 8 GB 系统内存 | 训练与推理分时运行，限制并发，模型和索引预先加载 |
| 无云端依赖 | Ollama、SQLite、Chroma 和静态前端均在本地运行 |
| 现场无缓存结果 | 核心请求必须创建新的 `agent_runs`、`agent_steps` 和业务版本记录 |
| LLM 输出不稳定 | 固定 JSON Schema、有限修复重试和确定性校验 |
| 文档可信性 | `verified` 与 `draft` 两级内容状态，`draft` 不进入正式路径 |
| 2 人协作 | 按首次计划和重规划两条业务主线分工，共享 Schema、API 和数据契约 |

## 3. 总体技术架构

### 3.1 架构选择

系统采用前后端分离的模块化单体：

- React 前端只通过 REST API 访问后端。
- FastAPI 负责请求校验、业务用例、事务和长操作状态。
- LangGraph 承载有状态 Agent 流程，节点调用确定性服务或 LLM Gateway。
- SQLite 保存业务状态、轨迹、训练记录和模型注册信息。
- Chroma 保存文档向量，SQLite FTS5 保存全文检索索引。
- Ollama 提供本地 LLM 推理。
- 训练流水线作为独立 CLI 运行，不嵌入 API 进程。

不采用微服务的原因：

- 两名开发者无法承担服务治理、网络容错和跨服务事务成本。
- SQLite 和 Chroma 已能覆盖课程项目数据规模。
- 单机部署更容易保证现场稳定和问题定位。

### 3.2 运行拓扑

```mermaid
flowchart LR
    Browser[桌面浏览器] -->|REST/JSON| API[FastAPI]
    API --> Agent[LangGraph Orchestrator]
    API --> Services[业务服务]
    Agent --> Gateway[LLM Gateway]
    Gateway --> Ollama[Ollama 127.0.0.1:11434]
    Agent --> RAG[RAG Service]
    Agent --> Graph[Knowledge Graph Service]
    Agent --> Planner[Planning Service]
    Agent --> Validator[Constraint Validator]
    Agent --> BKT[BKT Service]
    RAG --> SQLite[(SQLite + FTS5)]
    RAG --> Chroma[(Chroma)]
    Graph --> SQLite
    Planner --> SQLite
    Validator --> SQLite
    BKT --> SQLite
    Services --> SQLite
    CLI[Training/Admin CLI] --> SQLite
    CLI --> Artifacts[(模型与数据集文件)]
    Ollama --> Artifacts
```

### 3.3 进程和端口

| 进程 | 默认端口 | 职责 |
| --- | --- | --- |
| Ollama | `127.0.0.1:11434` | 模型推理和嵌入 |
| FastAPI | `127.0.0.1:8000` | API、Agent 启动和静态前端托管 |
| Vite | `127.0.0.1:5173` | 开发模式前端 |
| Training CLI | 无监听端口 | 数据校验、训练、评估和模型导出 |

服务只绑定回环地址。启动脚本必须进行以下检查：

1. Python、Node.js 和 Ollama 是否可执行。
2. 目标推理模型是否存在。
3. 端口是否被其他进程占用。
4. 数据库和 Chroma 目录是否可读写。
5. 当前激活模型是否通过评估。

## 4. 代码组织

### 4.1 目标目录结构

当前仓库尚无应用代码，建议按以下结构建立首个可运行版本：

```text
backend/
  app/
    main.py
    api/
      v1/
        goals.py
        diagnostics.py
        content.py
        paths.py
        learning.py
        replans.py
        traces.py
        admin.py
        models.py
    core/
      config.py
      errors.py
      logging.py
      idempotency.py
      time.py
    db/
      session.py
      models.py
      migrations/
      repositories/
    schemas/
      goal.py
      diagnostic.py
      content.py
      path.py
      learning.py
      replan.py
      training.py
    services/
      goals/
      diagnostics/
      rag/
      graph/
      planning/
      validation/
      bkt/
      replan/
      training/
      models/
    agent/
      state.py
      graph.py
      nodes/
      prompts/
    llm/
      gateway.py
      schemas.py
  tests/
    unit/
    integration/
    api/
    e2e/

frontend/
  src/
    app/
    pages/
    features/
      goals/
      diagnostics/
      content/
      paths/
      tasks/
      assessments/
      replans/
      models/
      traces/
    api/
    components/
    styles/
  tests/

training/
  datasets/
  configs/
  scripts/
  evaluation/
  artifacts/
  tests/

infra/
  scripts/
  modelfiles/
  demo-data/

docs/
```

### 4.2 分层规则

| 层 | 可以做 | 不可以做 |
| --- | --- | --- |
| API | 解析请求、调用用例、序列化响应、映射错误 | 直接拼接 SQL、直接调用 Ollama、直接规划路径 |
| Service | 执行业务规则、事务、领域计算 | 读取 HTTP 请求对象、直接返回数据库 ORM 对象 |
| Repository | 封装查询、锁、事务和持久化 | 包含用户可见业务决策 |
| Agent Node | 组装上下文、调用工具、写轨迹 | 绕过规则校验提升 `verified` |
| LLM Gateway | 统一模型调用、超时、重试和 JSON 解析 | 修改业务表、决定路径是否可行 |
| Training CLI | 数据校验、训练、评估和模型注册 | 直接服务在线用户请求 |

业务模块之间通过 Python 接口和 Pydantic Schema 通信，不共享可变的全局状态。

## 5. 领域模型与数据设计

### 5.1 聚合边界

| 聚合 | 核心实体 | 一致性边界 |
| --- | --- | --- |
| 学习目标 | `goals`、`goal_specs` | 目标字段、版本和状态 |
| 学习者 | `learner_profiles`、`mastery_snapshots` | 画像、掌握度和证据引用 |
| 课程知识 | `course_documents`、`document_chunks`、`knowledge_nodes` | 图谱和课程索引 |
| 诊断与证据 | `assessment_items`、`assessment_attempts`、`evidence` | 作答、评分和证据 |
| 学习路径 | `learning_paths`、`path_items`、`learning_tasks` | 路径发布和任务排期 |
| 学习执行 | `checkins` | 打卡和按打卡计算的执行偏差 |
| 重规划 | `replan_events` | 原路径、新路径、原因和接受状态 |
| Agent 运行 | `agent_runs`、`agent_steps`、`generated_contents` | 单次运行和可追踪输出 |
| 模型治理 | `training_datasets`、`training_runs`、`model_versions` | 数据、训练、评估和激活 |

### 5.2 核心表

#### 5.2.1 目标与画像

| 表 | 主要字段 | 关键约束 |
| --- | --- | --- |
| `users` | `id, display_name, created_at` | 本地单用户也保留用户键 |
| `goals` | `id, user_id, target_skill_id, raw_text, deadline, weekly_hours, daily_hours, status, version, created_at, updated_at` | 时间预算大于零；归档不删除历史 |
| `goal_specs` | `id, goal_id, version, spec_json, parse_status, created_at` | 每版不可修改；新解析生成新版本 |
| `learner_profiles` | `id, user_id, preferences_json, version, updated_at` | 每用户一条有效画像 |
| `mastery_snapshots` | `id, user_id, knowledge_node_id, previous_probability, new_probability, evidence_id, parameter_version, created_at` | 概率在 `[0,1]` |

#### 5.2.2 课程、知识图谱与题库

| 表 | 主要字段 | 关键约束 |
| --- | --- | --- |
| `course_documents` | `id, title, course_id, version, source_path, content_hash, status` | 同课程同版本不可重复导入 |
| `document_chunks` | `id, document_id, section, page, content, token_count, fts_rowid` | `chunk_id` 稳定且全局唯一 |
| `knowledge_nodes` | `id, canonical_name, domain, difficulty, estimated_hours, mastery_threshold, evidence_required, version` | 预计学时大于零 |
| `skill_nodes` | `id, name, description, level` | 名称规范化后唯一 |
| `prerequisite_edges` | `id, source_id, target_id, edge_type, weight, reason, version` | 同一有向边不重复；硬先修必须无环 |
| `knowledge_skill_map` | `knowledge_node_id, skill_node_id` | 复合主键 |
| `assessment_items` | `id, knowledge_node_id, item_type, difficulty, answer_schema, scoring_rule, status` | 每题必须映射知识节点 |

#### 5.2.3 路径与学习执行

| 表 | 主要字段 | 关键约束 |
| --- | --- | --- |
| `learning_paths` | `id, goal_id, parent_path_id, status, version, total_hours, risk_score, content_status, model_version_id, created_at` | 发布后只读 |
| `path_items` | `id, path_id, knowledge_node_id, sequence, planned_hours, state, unlock_rule` | 同一路径无重复节点 |
| `learning_tasks` | `id, path_item_id, title, task_type, planned_minutes, due_date, status` | 分钟数大于零 |
| `checkins` | `id, task_id, actual_minutes, completion_ratio, difficulty_feedback, note, planned_minutes_snapshot, schedule_delta_minutes, completion_delta, idempotency_key, created_at` | 幂等键唯一；偏差由本次打卡计算 |
| `assessment_attempts` | `id, item_id, user_id, answer_json, score, idempotency_key, submitted_at` | 同一幂等键返回原结果 |
| `evidence` | `id, user_id, knowledge_node_id, source_type, source_id, score, payload_json, created_at` | 来源记录必须存在 |
| `replan_events` | `id, path_id, new_path_id, trigger_type, before_json, after_json, reason, accepted, created_at` | 每次调整必须可比较前后路径 |

#### 5.2.4 Agent、训练与模型

| 表 | 主要字段 | 关键约束 |
| --- | --- | --- |
| `agent_runs` | `id, user_id, goal_id, graph_version, model_version_id, prompt_version, status, started_at, finished_at, request_hash` | 每次现场核心请求创建新记录 |
| `agent_steps` | `id, run_id, sequence, node_name, input_json, output_json, duration_ms, status, error_json` | 同一运行内序号唯一 |
| `generated_contents` | `id, run_id, goal_id, model_version_id, content_type, status, payload_json, citations_json` | `draft` 不可作为正式路径输入 |
| `idempotency_records` | `scope, idempotency_key, request_hash, response_json, created_at` | 主键为 `scope + idempotency_key` |
| `training_datasets` | `id, name, version, storage_path, sample_count, split_hash, status` | 数据集不可原地覆盖 |
| `training_runs` | `id, dataset_id, base_model, method, config_json, metrics_json, output_path, status, started_at, finished_at` | 必须记录随机种子和环境版本 |
| `model_versions` | `id, base_model, adapter_path, gguf_path, training_run_id, evaluation_json, status, activated_at` | 未通过评估不得激活 |

### 5.3 SQLite 配置

- 启用外键约束、WAL 日志和 `busy_timeout`。
- 单进程内使用短事务，不在 LLM 调用期间持有写事务。
- 所有写操作通过 Repository 执行。
- 时间统一保存为 UTC ISO 8601 字符串。
- JSON 字段保存前经过 Pydantic Schema 校验。
- 路径、BKT 参数、图谱和模型版本采用不可变版本记录。
- 数据库迁移使用版本化 SQL 或 Alembic，不在应用启动时静默破坏性重建。

### 5.4 数据不变量

1. `draft` 内容不得关联正式 `learning_paths`。
2. 发布路径必须引用通过 VR-001 至 VR-008 的校验结果。
3. 硬先修边组成的子图必须是无环图。
4. 每份证据必须能追溯到测验作答、打卡或人工确认记录。
5. 每次 BKT 更新必须引用参数版本和证据 ID。
6. 每次重规划必须生成新路径版本和 `ReplanEvent`。
7. 每个现场核心请求必须创建新的 `agent_run`。
8. 激活模型必须具有评估记录和通过的评估状态。

## 6. 核心组件设计

### 6.1 Goal Service

职责：

- 创建、读取、修改和归档目标。
- 将自然语言目标提交给 Agent 解析。
- 保存 `GoalSpec` 版本并校验时间字段。
- 在目标时间预算变化时触发重规划评估。

关键接口：

```python
class GoalService:
    def create_goal(self, request: GoalCreate) -> GoalDetail: ...
    def revise_goal(self, goal_id: str, request: GoalRevise) -> GoalDetail: ...
    def archive_goal(self, goal_id: str) -> None: ...
```

`GoalSpec` 至少包含：

```json
{
  "goal_text": "学习后端开发并掌握数据结构与算法",
  "target_skill_ids": ["skill-backend-basic"],
  "deadline": "2026-12-31",
  "weekly_hours": 10,
  "daily_hours": 2,
  "preferred_modes": ["reading", "coding"],
  "constraints": {
    "avoid_weekends": false,
    "max_session_minutes": 90
  },
  "completion_criteria": []
}
```

无法映射目标技能时，服务保存 `parse_status = needs_revision`，向前端返回可修改字段，不创建正式路径。

### 6.2 Diagnostic Service

职责：

- 根据目标技能的反向先修子图选择知识节点。
- 按关键节点覆盖、难度和已有证据生成诊断题。
- 将作答映射到知识节点并生成初始掌握度。
- 标记未覆盖或低置信度节点。

诊断题选择规则：

1. 目标关键节点优先于扩展节点。
2. 每个关键节点至少有一个诊断证据或显式低置信度标记。
3. 已有有效证据且未过期的节点可减少题量。
4. 同一知识点避免超过两道同难度题。
5. 题目总预计耗时显示在开始诊断前。

评分输出：

```json
{
  "diagnostic_id": "diag-001",
  "node_results": [
    {
      "knowledge_node_id": "python-function",
      "score": 0.5,
      "mastery": 0.42,
      "confidence": 0.7,
      "evidence_ids": ["ev-diag-001"]
    }
  ]
}
```

### 6.3 LLM Gateway

职责：

- 生成请求并调用 Ollama。
- 应用提示词模板、模型版本、温度和超时。
- 对 JSON 输出执行 Schema 校验。
- 在格式失败时执行最多两次修复重试。

接口：

```python
class LLMGateway:
    async def generate_json(
        self,
        task_type: str,
        prompt_version: str,
        payload: dict,
        schema: type[BaseModel],
        timeout_seconds: int = 90,
    ) -> LLMResult: ...
```

`LLMResult` 包含：

- `data`：通过 Schema 的结构化结果。
- `raw_text`：仅用于诊断，不写入业务表。
- `model_version_id`、`prompt_version`、`duration_ms`。
- `repair_attempts`。

约束：

- 业务服务不得直接调用 Ollama。
- 校验失败且超过重试上限时抛出 `LLM_SCHEMA_INVALID`。
- LLM 不得接收或返回数据库连接、文件路径或未授权资料。

### 6.4 RAG Service

职责：

- 导入 Markdown、TXT 和文本型 PDF。
- 提取文档、章节、页码和版本元数据。
- 生成稳定 `chunk_id`，写入 Chroma 和 SQLite FTS5。
- 执行向量与关键词混合检索。
- 返回真实引用，不生成虚假来源。

导入流程：

1. 校验扩展名、文件大小、路径和内容哈希。
2. 解析文本，识别标题和章节。
3. 按标题和 token 上限切分，保留页码。
4. 生成 `document_id / chunk_id`。
5. 通过嵌入模型生成向量并写入 Chroma。
6. 将文本和检索元数据写入 SQLite。
7. 校验向量记录和全文记录数量一致。
8. 事务失败时删除本次临时索引并回滚元数据。

混合检索：

```text
vector_score_normalized = normalize(vector_distance)
final_score = 0.65 * vector_score_normalized
            + 0.35 * normalized_bm25_score
```

默认流程：

- 候选召回 8 个片段。
- 应用课程、知识域、文档版本和软删除过滤。
- 按 `final_score` 排序，返回前 5 个。
- 低于最低阈值时返回 `evidence_insufficient`。

引用对象：

```json
{
  "document_id": "doc-python-001",
  "chunk_id": "doc-python-001-c03",
  "title": "Python 程序设计课程大纲",
  "section": "函数与模块",
  "page": 12,
  "score": 0.82
}
```

引用校验规则：

- `chunk_id` 必须存在于当前可用索引。
- `document_id` 必须与片段记录一致。
- 软删除文档只能展示历史引用，不得作为新生成依据。
- Citation Validator 删除模型虚构引用，并降低内容可信级别。

### 6.5 Knowledge Graph Service

职责：

- 管理知识节点、技能节点、先修边和题目映射。
- 提取目标技能的反向先修子图。
- 合并模型候选节点并进行实体归一化。
- 校验 DAG、孤立节点和必须映射关系。

边类型：

- `HARD_PREREQUISITE`
- `SOFT_PREREQUISITE`
- `MAPS_TO_SKILL`
- `COVERED_BY_COURSE`
- `ASSESSED_BY`

实体归一化顺序：

1. ID 精确匹配。
2. 规范化名称精确匹配。
3. 别名表匹配。
4. 去除空白、大小写和常见标点后的名称匹配。
5. 无法匹配时创建候选节点，不自动合并到高影响节点。

图写入规则：

- 写入硬先修边前执行环路检测。
- 检测到环时返回完整环路和冲突边。
- 已发布路径不重新绑定节点版本。
- 图版本变化后，新规划使用新版本，历史解释保留旧版本。

### 6.6 Planning Service

职责：

- 从目标技能提取必需知识子图。
- 根据有效掌握度删除已掌握节点。
- 对未掌握节点执行拓扑排序。
- 将节点分配到可用时间窗口。
- 生成主路径和候选替代顺序。

算法步骤：

1. 从 `target_skill_ids` 反向遍历 `HARD_PREREQUISITE`，得到硬先修闭包。
2. 加入软先修节点作为可选候选。
3. 过滤掌握概率达到阈值且证据有效的节点。
4. 合并模型候选节点，但以图谱现有节点优先。
5. 对剩余子图执行 Kahn 拓扑排序。
6. 使用风险函数对同层可排序节点排序。
7. 按每日最大时长和每周时间预算生成时间窗口。
8. 生成主路径和至多两个替代顺序。
9. 交给 Constraint Validator 校验。
10. 校验失败时根据 `repair_hint` 执行有限修复。

风险函数：

```text
risk = 0.50 * prerequisite_gap
     + 0.25 * schedule_pressure
     + 0.15 * difficulty_jump
     + 0.10 * context_switch
```

排序规则必须确定性可复现：

- 同风险值按先修层级、难度和节点 ID稳定排序。
- 不因随机种子不同改变主路径。
- 模型候选顺序只作为软先修排序输入，不覆盖硬先修。

时间分配：

- 每节点按预计学时拆分为不超过每日最大时长的任务。
- 不跨日拆分短任务，除非单节点超过每日上限。
- 周末限制和偏好影响时间窗口，不改变硬先修顺序。
- 剩余时间不足时返回 `PLAN_INFEASIBLE` 和替代方向。

### 6.7 Constraint Validator

校验器是纯函数式规则层，不调用 LLM。

| 规则 | 校验 | 失败结果 |
| --- | --- | --- |
| VR-001 | 硬先修已掌握或排在目标节点前 | `missing_prerequisite` |
| VR-002 | 总学时不超过预算 | `time_budget_exceeded` |
| VR-003 | 每日和每周负荷不超上限 | `load_limit_exceeded` |
| VR-004 | 路径节点不重复 | `duplicate_node` |
| VR-005 | `verified` 节点有真实引用 | `missing_citation` |
| VR-006 | 验收任务映射有效知识点 | `invalid_assessment_mapping` |
| VR-007 | 已完成节点状态正确锁定 | `completed_node_unlocked` |
| VR-008 | 重规划不破坏未完成硬先修 | `replan_prerequisite_conflict` |

统一输出：

```json
{
  "is_valid": false,
  "errors": [
    {
      "rule_id": "VR-001",
      "node_id": "algo-recursion",
      "message": "递归需要函数与调用栈基础",
      "related_node_ids": ["python-function"]
    }
  ],
  "repair_hint": "insert_before",
  "checked_at": "2026-10-20T08:00:00Z"
}
```

规则实现必须覆盖：

- 输入不可变，校验不修改候选路径。
- 错误顺序稳定，便于前端和测试比较。
- 每条错误可映射到至少一个节点或全局字段。
- LLM 解释不能覆盖 `is_valid = false`。

### 6.8 BKT Service

职责：

- 按知识节点读取版本化 BKT 参数。
- 从有效证据计算掌握度后验概率。
- 保存更新前后的快照。
- 判断是否达到掌握阈值。

参数：

| 参数 | 默认范围 |
| --- | --- |
| `p_init` | 由诊断结果初始化 |
| `p_learn` | `0.15` 至 `0.30` |
| `p_slip` | `0.05` 至 `0.15` |
| `p_guess` | 根据题型配置 |

更新公式：

```text
P(L_t | correct) = P(L_t)(1 - p_slip)
                 / [P(L_t)(1 - p_slip) + (1 - P(L_t))p_guess]

P(L_t | wrong) = P(L_t)p_slip
               / [P(L_t)p_slip + (1 - P(L_t))(1 - p_guess)]

P(L_{t+1}) = P(L_t | evidence)
           + (1 - P(L_t | evidence)) * p_learn
```

实现要求：

- 输入概率和参数先做范围校验。
- 分母为零或非法参数时返回 `BKT_PARAMETER_INVALID`，不得静默使用 NaN。
- 同一证据 ID 只能应用一次。
- 缺失参数时使用带版本的默认参数，并在快照中记录回退原因。

### 6.9 Evidence Evaluation

题型处理：

| 题型 | 评分方式 |
| --- | --- |
| 单选、多选、判断 | 按 `answer_schema` 确定性评分 |
| 填空 | 规范化文本与可接受答案集合匹配 |
| 简答 | 规则评分或 LLM 生成建议，最终分数需规则确认 |
| 代码题 | 本期不执行代码，按答案 Schema、评分规则或人工确认生成证据 |

LLM 评分约束：

- LLM 返回值必须包含 `score`、`rationale` 和 `confidence`。
- 业务分数必须由版本化评分规则截断和确认。
- 评分失败不创建证据，不触发 BKT。
- 原始答案按隐私要求处理，日志只保存摘要或哈希。

### 6.10 Replan Service

职责：

- 计算执行偏差。
- 判断是否触发局部或全局重规划。
- 生成新路径版本和前后差异。
- 支持学生接受或拒绝。

触发条件：

- 掌握度低于 `0.45`。
- 同一任务连续两次未完成。
- 学习时间或截止日期变化。
- 新证据与高掌握度冲突。
- 目标范围变化。

决策矩阵：

| 条件 | 动作 |
| --- | --- |
| 单节点低于阈值 | 插入补强节点并顺延后续 |
| 连续两次未完成 | 降低任务粒度或重排时间窗口 |
| 时间预算变化不超过 30% | 优先局部重排 |
| 时间预算变化超过 30% | 全局重规划 |
| 目标技能或范围变化 | 全局重规划 |
| 多个关键节点持续不达标 | 全局重规划 |

重规划必须复用 GraphPlanner 和 Constraint Validator，不允许存在独立的“绕过校验”路径。

### 6.11 Model Registry

职责：

- 注册数据集、训练运行、适配器和 GGUF。
- 保存评估指标和模型状态。
- 控制模型激活和回退。

状态：

```text
registered -> evaluating -> approved -> active
                         \-> rejected
active -> inactive
```

激活规则：

- 状态必须为 `approved`。
- 评估集版本和指标必须存在。
- 记录激活时间和前一个激活版本。
- Ollama 加载失败时恢复前一版本。

## 7. Agent 工作流设计

### 7.1 AgentState

```text
AgentState
  run_id
  user_id
  goal_id
  workflow_type
  model_version_id
  prompt_version
  goal_spec
  learner_snapshot
  diagnostic_plan
  diagnostic_answers
  evidence_chunks
  candidate_content
  content_status
  graph_subgraph
  candidate_path
  validation_result
  explanation
  execution_snapshot
  replan_decision
  new_path
  retry_counts
  errors
  trace_refs
```

`workflow_type` 取值：

- `initial_plan`：首次学习计划。
- `evidence_update`：证据验收和掌握度更新。
- `replan`：时间、执行或证据触发重规划。

### 7.2 首次计划子图

```mermaid
flowchart TD
    A[GoalInterpreter] --> B[ConceptGenerator]
    B --> C[RAGTool]
    C --> D[ContentGenerator]
    D --> E[ContentValidator]
    E -->|draft| X[返回草稿与证据缺口]
    E -->|verified| F[DiagnosticPlanner]
    F --> G[DiagnosticEvaluator]
    G --> H[ProfileBuilder]
    H --> I[GraphPlanner]
    I --> J[ConstraintValidator]
    J -->|失败且可修复| I
    J -->|不可修复| K[返回不可行与替代方案]
    J -->|通过| L[PlanExplainer]
    L --> M[保存待接受路径]
```

### 7.3 学习后重规划子图

```mermaid
flowchart TD
    A[CheckinReceived] --> B[ExecutionMonitor]
    B --> C[EvidenceEvaluator]
    C --> D[BKTUpdater]
    D --> E[ReplanDecider]
    E -->|保持| F[返回原路径与最新掌握度]
    E -->|局部重规划| G[LocalReplanner]
    E -->|全局重规划| H[GlobalReplanner]
    G --> I[ConstraintValidator]
    H --> I
    I -->|通过| J[ReplanNarrator]
    J --> K[保存待接受新路径版本]
    I -->|失败| L[返回冲突与替代方向]
```

### 7.4 节点幂等和重试

- 每个节点执行前记录 `run_id + sequence + node_name`。
- 已完成节点在相同输入下可以复用其结构化输出。
- 现场核心请求仍创建新运行和新轨迹，不复用旧路径。
- LLM 格式修复只重试当前节点，不重跑已通过节点。
- 规划校验最多重试 3 次。
- 节点超时后状态标记为 `failed`，保留输入和已完成节点。

### 7.5 轨迹记录

每次 Agent 步骤写入：

- `run_id`
- `sequence`
- `node_name`
- `input_json`
- `output_json`
- `duration_ms`
- `status`
- `error_json`

轨迹要求：

- 不记录完整密钥和敏感原始答案。
- 引用只记录真实 `chunk_id`。
- 前端按顺序展示节点、耗时、状态和校验结果。
- 相同 `run_id` 的步骤序号唯一。

## 8. API 技术契约

### 8.1 通用约定

- 基础路径：`/api/v1`
- JSON 字段使用 `snake_case`，与设计方案中的 API 示例保持一致。
- 时间使用 ISO 8601。
- 幂等请求使用 `Idempotency-Key` 请求头。
- 每个错误响应包含：

```json
{
  "error": {
    "code": "PLAN_INFEASIBLE",
    "message": "当前时间预算无法完成目标",
    "details": {
      "rule_id": "VR-002"
    },
    "trace_id": "run-20261020-001"
  }
}
```

### 8.2 状态码

| 状态码 | 使用场景 |
| --- | --- |
| 200 | 查询成功或幂等重放 |
| 201 | 创建目标、证据或路径成功 |
| 202 | 长操作已接受但未完成 |
| 400 | 请求字段或业务输入非法 |
| 404 | 目标、路径或运行不存在 |
| 409 | 版本冲突、重复接受或状态不允许 |
| 422 | Schema 不匹配 |
| 500 | 未预期内部错误 |
| 503 | Ollama 不可用或模型未激活 |

### 8.3 关键接口

#### 目标

| 方法 | 路径 | 技术说明 |
| --- | --- | --- |
| `POST` | `/goals` | 创建目标并启动解析，返回 `goal_id` 和 `run_id` |
| `GET` | `/goals/{goal_id}` | 返回目标、最新 `GoalSpec` 和状态 |
| `PATCH` | `/goals/{goal_id}` | 修改目标；已生效路径不原地修改 |
| `POST` | `/goals/{goal_id}/archive` | 归档目标 |

#### 诊断

| 方法 | 路径 | 技术说明 |
| --- | --- | --- |
| `POST` | `/diagnostics` | 根据 `goal_id` 生成诊断集 |
| `POST` | `/diagnostics/{diagnostic_id}/submit` | 提交答案并生成证据与初始掌握度 |

#### 内容与路径

| 方法 | 路径 | 技术说明 |
| --- | --- | --- |
| `POST` | `/content/generate` | 生成候选知识、任务和题目 |
| `POST` | `/paths/generate` | 生成并校验候选路径 |
| `GET` | `/paths/{path_id}` | 返回路径、引用、锁定原因和校验结果 |
| `POST` | `/paths/{path_id}/accept` | 接受路径；使用乐观版本检查 |

#### 学习执行

| 方法 | 路径 | 技术说明 |
| --- | --- | --- |
| `GET` | `/tasks/today` | 按本地日期查询当日任务 |
| `POST` | `/tasks/{task_id}/check-in` | 保存打卡并计算执行偏差 |
| `POST` | `/assessments/{item_id}/submit` | 评分、生成证据、更新 BKT |

#### 重规划与轨迹

| 方法 | 路径 | 技术说明 |
| --- | --- | --- |
| `GET` | `/paths/{path_id}/replans/preview` | 预览重规划结果，不替换当前路径 |
| `POST` | `/replans/{replan_id}/accept` | 接受新路径版本 |
| `GET` | `/traces/{run_id}` | 查询 Agent 运行状态、最终资源 ID 和步骤 |

#### 训练与模型

| 方法 | 路径 | 技术说明 |
| --- | --- | --- |
| `POST` | `/admin/import` | 导入课程、图谱和题库 |
| `POST` | `/admin/datasets` | 注册数据集 |
| `POST` | `/admin/training-runs` | 创建训练任务记录并启动 CLI |
| `GET` | `/admin/training-runs/{run_id}` | 查询训练状态和指标 |
| `POST` | `/admin/training-runs/{run_id}/evaluate` | 执行基线和微调模型评估 |
| `GET` | `/models` | 查询模型版本和部署状态 |
| `POST` | `/models/{model_id}/activate` | 激活已批准模型 |
| `POST` | `/admin/reset-demo` | 重置业务演示数据 |

### 8.4 长操作流程

目标解析、诊断生成、内容生成、路径生成和重规划预览可能调用一次或多次本地 LLM，属于长操作。技术实现采用“创建运行 + 查询状态”的流程：

1. 前端提交业务请求并携带幂等键。
2. API 创建业务草稿记录和新的 `agent_run`。
3. API 返回 `202 Accepted`，包含 `run_id` 和 `trace_url`。
4. 前端轮询 `/traces/{run_id}`，展示当前 Agent 节点和状态。
5. 运行成功后，轨迹响应返回 `result_type` 和 `result_id`。
6. 前端再通过对应资源接口获取完整结果。
7. 运行失败时，轨迹响应返回稳定错误码和是否可重试。

该流程不缓存旧业务结果。每次 POST 都创建新的运行记录；运行内部断点恢复只复用本次运行已完成节点的结构化输出。

### 8.5 目标创建示例

请求：

```json
{
  "goal_text": "我想在两个月内学习数据结构与算法，并具备后端开发入门能力",
  "target_skill_id": "skill-backend-basic",
  "deadline": "2026-12-31",
  "weekly_hours": 10,
  "daily_hours": 2,
  "preferred_modes": ["reading", "coding"],
  "constraints": {
    "avoid_weekends": false,
    "max_session_minutes": 90
  }
}
```

响应：

```json
{
  "goal_id": "goal-001",
  "run_id": "run-20261020-001",
  "status": "parsing",
  "trace_url": "/api/v1/traces/run-20261020-001"
}
```

### 8.6 路径生成响应

```json
{
  "path_id": "path-001",
  "run_id": "run-20261020-003",
  "status": "valid",
  "content_status": "verified",
  "model_version": "model-qlora-v1",
  "total_hours": 72,
  "risk_score": 0.31,
  "items": [
    {
      "sequence": 1,
      "knowledge_node_id": "python-function",
      "name": "函数与模块",
      "planned_hours": 6,
      "mastery": 0.35,
      "state": "ready",
      "evidence": ["doc-python-001-c03"]
    }
  ],
  "validation": {
    "is_valid": true,
    "errors": []
  },
  "explanation": "先补强函数和模块，再进入递归与复杂度分析。"
}
```

### 8.7 测验提交响应

```json
{
  "evidence_id": "ev-001",
  "knowledge_node_id": "algo-recursion",
  "score": 0.4,
  "mastery": {
    "previous": 0.62,
    "current": 0.54,
    "threshold": 0.75
  },
  "replan_required": true,
  "replan_reason": "递归掌握度低于 0.45 的补强阈值"
}
```

## 9. 事务、幂等与并发

### 9.1 事务边界

| 操作 | 事务内容 |
| --- | --- |
| 创建目标 | 写目标、初始 `GoalSpec` 状态和运行记录 |
| 提交诊断 | 写作答、评分、证据和掌握度快照 |
| 接受路径 | 校验版本、更新当前路径、记录接受时间 |
| 提交打卡 | 写打卡、更新任务状态和执行偏差 |
| 提交测验 | 写作答、证据、BKT 快照和重规划判断 |
| 接受重规划 | 写 `ReplanEvent`、新路径状态和旧路径状态 |

LLM 调用、向量生成和训练执行不放在长写事务中。先生成候选结果，再使用短事务校验并写入。

### 9.2 幂等策略

- 客户端为打卡、测验和接受重规划生成 `Idempotency-Key`。
- 服务端计算 `scope + key` 并保存响应副本。
- 重复请求返回原响应，不重复更新任务、证据或 BKT。
- 同一键但请求体哈希不同返回 `409 IDEMPOTENCY_CONFLICT`。

### 9.3 乐观并发

- 目标和路径具有 `version`。
- 接受路径、修改目标和接受重规划必须提交当前版本。
- 版本不匹配返回 `409 VERSION_CONFLICT`，前端重新拉取最新状态。

## 10. 前端技术设计

### 10.1 技术栈

- React、TypeScript、Vite。
- React Router 负责页面路由。
- TanStack Query 管理 API 缓存和请求状态。
- 不引入全局状态库，跨页面状态通过服务器数据和路由参数恢复。
- 路径图使用 React Flow 或等价节点图组件。

### 10.2 路由

| 路由 | 页面 |
| --- | --- |
| `/goals/new` | 目标设置 |
| `/goals/:goal_id/diagnostics` | 基础诊断 |
| `/goals/:goal_id/content` | 内容生成 |
| `/paths/:path_id` | 学习路径 |
| `/tasks/today` | 今日任务 |
| `/assessments/:item_id` | 证据验收 |
| `/paths/:path_id/replans/:replan_id` | 重规划预览 |
| `/models` | 模型管理 |
| `/traces/:run_id` | AI 轨迹 |

### 10.3 数据请求

- Query key 使用业务实体和版本，例如 `["path", path_id, version]`。
- 长耗时操作显示当前阶段，并将 `run_id` 保存在路由或 Query 缓存。
- 操作成功后只失效相关查询，不全量刷新页面。
- 409 冲突时展示最新版本和差异，不自动覆盖。
- `draft` 内容禁止触发“发布路径”操作。

### 10.4 路径图

节点数据：

```text
pathItemId
knowledge_node_id
name
sequence
planned_hours
mastery
state
citations
unlockRule
```

视觉状态：

- 绿色：已达到掌握阈值。
- 蓝色：当前可学习。
- 灰色：受硬先修锁定。
- 橙色：需要补强。
- 红色：校验错误或延期风险。

颜色必须配合文本标签，不能作为唯一状态信号。

## 11. 训练、评估与模型部署

### 11.1 数据集结构

```json
{
  "sample_id": "sft-0001",
  "task_type": "path_planning",
  "instruction": "为有 Python 基础、每周学习 10 小时的学生规划后端开发路径",
  "input": {},
  "target_json": {},
  "citations": [],
  "source": "curated",
  "license": "project-curated",
  "dataset_version": "ds-v1"
}
```

数据校验：

- `task_type` 属于允许集合。
- `target_json` 满足对应 JSON Schema。
- 引用存在于允许的 RAG 资料。
- 训练、验证和测试按目标或模板分组。
- 样本哈希和整库哈希可复现。

### 11.2 训练命令

```powershell
python training/scripts/train_qlora.py --config training/configs/qwen15-qlora-v1.yaml
```

训练流程：

1. 校验数据集并计算哈希。
2. 运行基座模型评估。
3. 执行 QLoRA 训练，保存检查点和日志。
4. 在隔离测试集上评估。
5. 通过门槛后导出适配器或 GGUF。
6. 注册模型版本。
7. 由人工或启动脚本激活已批准模型。

### 11.3 训练配置

| 参数 | 默认值 |
| --- | --- |
| 量化 | 4-bit NF4 |
| LoRA rank | 16 |
| LoRA alpha | 32 |
| dropout | 0.05 |
| batch size | 1 |
| 梯度累积 | 8 至 16 |
| 最大长度 | 1024 |
| epochs | 1 至 3 |
| 学习率 | `1e-4` 至 `2e-4` |

### 11.4 评估报告

至少包含：

- JSON Schema 合法率。
- 引用存在率。
- 硬先修冲突率。
- 路径规则通过率。
- 20 个未参与训练目标的通过数量。
- 基座与微调模型同输入对比样例。
- 数据哈希、模型哈希和环境版本。

### 11.5 推理部署

- 训练和应用分时运行。
- 模型激活后由 Ollama 加载。
- Gateway 在首次请求前检查模型是否可见。
- 当前激活模型 ID 写入每次 `agent_runs`。
- 现场演示保留基座与微调模型两个配置用于对比。

## 12. 安全与隐私实现

- 服务只绑定 `127.0.0.1`。
- 上传文件经过扩展名、MIME、大小和规范化路径校验。
- 禁止返回服务器绝对路径。
- 日志对答案使用摘要或哈希。
- API 错误返回用户可读信息，完整堆栈只写本地日志。
- 训练数据、课程资料和模型均记录来源与授权说明。
- 不在提示词中发送未授权文档和完整用户隐私。
- `admin` 接口只在本地开发或演示模式启用。

## 13. 可观测性与故障处理

### 13.1 日志

结构化日志字段：

- `timestamp`
- `level`
- `trace_id`
- `run_id`
- `goal_id`
- `node_name`
- `duration_ms`
- `error_code`

### 13.2 错误码

| 错误码 | 含义 | 用户动作 |
| --- | --- | --- |
| `MODEL_UNAVAILABLE` | Ollama 或模型不可用 | 启动 Ollama 或安装模型 |
| `LLM_SCHEMA_INVALID` | 模型输出多次修复仍非法 | 重试当前节点 |
| `RAG_EVIDENCE_INSUFFICIENT` | 无足够证据 | 补充课程资料 |
| `GRAPH_CYCLE_DETECTED` | 硬先修存在环 | 修正知识图谱 |
| `PLAN_INFEASIBLE` | 时间预算不足 | 调整时间或目标范围 |
| `VERSION_CONFLICT` | 数据已被其他操作更新 | 刷新后重试 |
| `IDEMPOTENCY_CONFLICT` | 同一幂等键请求体不同 | 使用新键 |
| `MODEL_NOT_APPROVED` | 模型未通过评估 | 选择已批准版本 |
| `TRAINING_CHECKPOINT_MISSING` | 无法恢复训练 | 从最近完整检查点重启 |

### 13.3 恢复策略

- 应用重启后读取已提交业务数据。
- Agent 从中断节点重试时，复用已完成节点的结构化输出。
- 现场闭环不允许复用旧路径，但允许一次运行内部断点恢复。
- 导入失败时回滚本次 SQLite 记录和临时 Chroma 索引。
- 模型激活失败恢复前一激活版本。

## 14. 测试策略

### 14.1 单元测试

| 模块 | 必测内容 |
| --- | --- |
| Goal | 字段校验、版本更新、解析失败保存 |
| Diagnostic | 节点覆盖、评分映射、低置信度标记 |
| RAG | 切分、混合分数、过滤、引用存在性 |
| Graph | DAG、拓扑排序、实体归一化、环路拒绝 |
| Planning | 缺失知识计算、时间分配、确定性排序 |
| Validator | VR-001 至 VR-008 每条规则 |
| BKT | 正确、错误、非法参数、幂等 |
| Replan | 触发条件、局部和全局选择 |
| Model Registry | 激活门槛和回退 |

### 14.2 集成测试

- FastAPI 与 SQLite Repository。
- Chroma 与 SQLite FTS5 混合检索。
- Ollama Gateway 超时和 JSON 修复。
- LangGraph 首次计划和重规划子图。
- 训练 CLI 数据集校验和 Smoke Test。

### 14.3 API 测试

- 请求和响应 Schema。
- 幂等重放和冲突。
- 乐观并发冲突。
- 错误码和 `trace_id`。
- 未批准模型激活被拒绝。

### 14.4 端到端测试

Playwright 主流程：

1. 创建目标。
2. 完成诊断。
3. 生成并接受路径。
4. 提交打卡。
5. 提交未达标测验。
6. 查看 BKT 变化和重规划预览。
7. 接受重规划并查看差异。
8. 打开 Agent 轨迹。

### 14.5 现场验收

- 连续执行 AT-001 至 AT-015。
- 至少一次关闭外部网络。
- 至少截图或记录一次失败恢复。
- 验证每次核心运行具有新 `run_id`、时间戳和步骤轨迹。

## 15. 性能设计

| 指标 | 技术措施 |
| --- | --- |
| RAG 小于 2 秒 | 预建索引、限制召回数、SQLite FTS5 与 Chroma 复用连接 |
| 图搜索小于 1 秒 | 图谱常驻内存或短事务读取，限制子图规模 |
| 规则校验小于 500 毫秒 | 纯 Python 确定性规则，无 LLM 调用 |
| BKT 小于 100 毫秒 | 单节点参数缓存和短事务 |
| 首次输出小于 10 秒 | 模型预热、限制提示词长度和流式状态 |
| 完整路径小于 120 秒 | 节点级超时、复用证据、限制重试 |
| API 查询小于 500 毫秒 | 必要索引、分页和避免 N+1 查询 |

SQLite 必要索引：

- `goals(user_id, status)`
- `learning_paths(goal_id, version)`
- `path_items(path_id, sequence)`
- `learning_tasks(path_item_id, due_date, status)`
- `assessment_attempts(item_id, user_id, submitted_at)`
- `mastery_snapshots(user_id, knowledge_node_id, created_at)`
- `agent_steps(run_id, sequence)`

## 16. 双人协作与交付

### 16.1 责任边界

| 成员 | 首次学习计划 | 学习后重规划 | 共享 |
| --- | --- | --- | --- |
| A | 目标解析、诊断、内容生成、RAG、知识图谱、首次规划、校验、任务拆解 | 提供路径和节点接口 | API/Schema、训练数据审核、联调 |
| B | 提供证据和掌握度接口 | 打卡、评分、BKT、执行偏差、重规划、路径差异、后续任务 | 数据迁移、现场演练、测试 |

### 16.2 共享契约

先冻结以下内容，再并行开发：

- `GoalSpec`
- `LearnerSnapshot`
- `LearningPath`
- `PathItem`
- `ValidationResult`
- `Evidence`
- `MasterySnapshot`
- `ReplanEvent`
- 错误码和幂等键格式

契约变化必须同时更新：

1. Pydantic Schema。
2. OpenAPI。
3. 数据库迁移。
4. 前端 TypeScript 类型。
5. 本技术文档。
6. 相关测试。

### 16.3 周里程碑

| 周次 | A 的主要交付 | B 的主要交付 | 共同检查 |
| --- | --- | --- | --- |
| 1 | 目标、图谱、路径接口设计 | BKT、证据、重规划接口设计 | 环境与契约冻结 |
| 2 | 图谱 v1、目标解析 | BKT、证据和评分基础 | 数据 Schema 与单测 |
| 3 | RAG 与内容生成 | 打卡、执行偏差 | 数据质量与引用 |
| 4 | 训练和模型接入 | 重规划预览 | 微调模型评估 |
| 5 | 首次计划后端闭环 | 学习后重规划后端闭环 | 后端六阶段联调 |
| 6 | 路径与内容 API | 学习与重规划 API | OpenAPI 冻结 |
| 7 | 目标、诊断、路径页面 | 任务、验收、重规划页面 | 学生端完整流程 |
| 8 | 轨迹和模型管理 | 异常与重试 | 安全与性能 |
| 9 | 首次计划演练 | 重规划演练 | 三轮现场闭环 |
| 10 | 演示材料 A 部分 | 演示材料 B 部分 | 最终彩排与冻结 |

## 17. 技术风险与缓解

| 风险 | 影响 | 技术缓解 |
| --- | --- | --- |
| 1.5B 模型 JSON 不稳定 | 节点失败或路径不完整 | 固定 Schema、修复重试、确定性校验 |
| 8 GB 内存不足 | 推理与前端同时运行时卡顿 | 预热、限制并发、训练和推理分时 |
| SQLite 写入竞争 | 长运行导致锁等待 | 短事务、WAL、LLM 调用不持有事务 |
| Chroma 与 SQLite 索引不一致 | 引用失效 | 导入后数量校验、统一文档状态 |
| 图谱生成错误 | 路径顺序错误 | DAG 校验、人工审核、规则单测 |
| BKT 参数不合理 | 掌握度异常 | 版本化参数、范围校验、回退记录 |
| 两人接口漂移 | 联调阻塞 | 第 1 周冻结核心 Schema，第 6 周冻结 API |
| 重规划与首次规划重复实现 | 行为不一致 | 两条流程复用 GraphPlanner 与 Validator |
| 现场使用缓存结果 | 验收失败 | 每次请求新 `run_id`、时间戳和 Agent 轨迹 |

## 18. 需求追踪

| 功能需求 | 主要模块 | 主要数据 | API | 验收 |
| --- | --- | --- | --- | --- |
| FR-001 至 FR-005 | Goal、Diagnostic、Profile | `goals`、`goal_specs`、`mastery_snapshots` | `/goals`、`/diagnostics` | AT-001、AT-002、AT-005 |
| FR-006 至 FR-012 | RAG、Graph、Planning、Validator、Explainer | `course_documents`、`document_chunks`、`knowledge_nodes`、`learning_paths` | `/admin/import`、`/content/generate`、`/paths/generate` | AT-001、AT-003、AT-004、AT-010 |
| FR-013 至 FR-017 | Planning、Learning、BKT、Replan | `learning_tasks`、`checkins`、`evidence`、`replan_events` | `/tasks`、`/assessments`、`/replans` | AT-005、AT-006、AT-007 |
| FR-018 至 FR-021 | Agent、Gateway、Recovery | `agent_runs`、`agent_steps` | `/traces/{run_id}` | AT-008、AT-009、AT-010 |
| FR-022 至 FR-023 | Demo、Content、RAG、Graph | 演示数据、生成内容、索引 | `/admin/reset-demo`、`/content/generate` | AT-011、AT-013、AT-015 |
| FR-024 至 FR-028 | Training、Evaluation、Registry、Gateway | `training_datasets`、`training_runs`、`model_versions` | `/admin/datasets`、`/models` | AT-012、AT-014 |
| FR-029 | ContentValidator、Planning、Validator | `generated_contents`、路径状态 | `/paths/generate` | AT-013 |
| FR-030 | Agent、Tracing、API | `agent_runs`、`agent_steps`、时间戳 | 全部核心 POST 接口 | AT-015 |

| 非功能需求 | 技术实现 | 验证方式 |
| --- | --- | --- |
| NFR-PERF-001 至 NFR-PERF-007 | 索引、预热、限制重试、短事务 | 性能测试 |
| 可靠性 | 幂等、检查点、回退、断点恢复 | 故障注入 |
| 可解释性 | 引用、规则 ID、Agent 轨迹 | AT-010、AT-015 |
| 安全与隐私 | 回环监听、路径校验、日志脱敏 | 安全测试 |
| 可维护性 | 分层、Schema、版本化、单测 | 代码审查与 CI |

## 19. 技术验收结论

技术基线采用模块化单体而非微服务。首次学习计划和学习后重规划共用知识图谱、路径规划器和规则校验器，LLM 仅生成候选内容和自然语言解释。

现场闭环的技术证据链为：

```text
浏览器请求
  -> 新建 agent_run
  -> Agent 步骤和工具调用
  -> 真实 RAG 引用
  -> 图谱与规则校验
  -> 路径版本
  -> 打卡/证据
  -> BKT 快照
  -> 新路径版本与 ReplanEvent
  -> 可查询的完整轨迹
```

只有该链条全部产生本次运行的真实记录，技术实现才满足 AT-015 的现场验收要求。
